#Nombre: MARIO JIMENEZ ARREOLA
#Carrera: Informática
#Materia: Desarrollo de Aplicaciones Web
#Ejercicio o Práctica "ACTIVIDAD DE EVALUACION"

class caja:
    def __init__(self,ancho,largo,alto):
        self.ancho=ancho
        self.largo=largo
        self.alto=alto
        self.volumen=ancho,alto,largo
        self.AreaFrontal=ancho,alto
        self.AreaLateral=largo,alto
        self.AreaSuperior=largo,ancho
    def calcularvolumen(self,ancho,alto,largo):
         return self.volumen, ancho*alto*largo
    def calcularAreaFrontal(self,ancho,alto):
        return self.AreaFrontal, ancho*alto
    def calcularAreaLateral(self,largo,alto):
        return self.AreaLateral, largo*alto
    def calcularAreaSuperior(self,largo,ancho):
        return self.AreaSuperior, largo*ancho


class mostrarcontenido(caja):
    def __init__(self,ancho,largo,alto):
        super ().__init__(ancho,largo,alto)
        

class caja:
    def __init__(self, areafrontal, arealateral, areasuperior):
        self.areafrontal=areafrontal
        self.arealateral=arealateral
        self.areasuperior=areasuperior
    def calcularAreatotal(self, areafrontal, arealateral,areasuperior):
        return self.calcularAreatotal,2*areafrontal+2*arealateral+2*areasuperior

class mostrar(caja):
    def __init__(self,AreaFrontal,AreaLateral,AreaSuperior):
        super () .__init__ (AreaFrontal,AreaLateral,AreaSuperior) 
