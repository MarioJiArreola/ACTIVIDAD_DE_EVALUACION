#Nombre: MARIO JIMENEZ ARREOLA
#Carrera: Informática
#Materia: Desarrollo de Aplicaciones Web
#Ejercicio o Práctica "ACTIVIDAD DE EVALUACION"


class caja:
     def __init__(self, Area, Volumen):
        self.Area=Area
        self.Volumen=Volumen

     def Mostrarcontenido(self, Area,Volumen):
        if self.caja >(5,6,1.5):
            print (self.Area, "Si cabe")
        else:
            print (self.Volumen, "no cabe")
            
     def MostrarAreatotal(self,area,volumen):
         return calcularAreatotal in self.MostramosVolumen



    
